import os
import pickle
import time
from utils.logger import logger
from utils.config import BASE_DIR

class SimulationCache:
    def __init__(self, cache_dir=None):
        if cache_dir is None:
            self.cache_dir = os.path.join(BASE_DIR, "data", "cache")
        else:
            self.cache_dir = cache_dir
            
        # Cache folder illati create pannuvom
        if not os.path.exists(self.cache_dir):
            os.makedirs(self.cache_dir)
            logger.info(f"Cache directory created at {self.cache_dir}")

    def get_cache_path(self, key):
        """Oru specific key-ku file path generate pannum"""
        return os.path.join(self.cache_dir, f"{key}.pkl")

    def set(self, key, data):
        """Data-va cache-la save panna"""
        try:
            path = self.get_cache_path(key)
            with open(path, 'wb') as f:
                pickle.dump(data, f)
            logger.info(f"Data cached successfully for key: {key}")
        except Exception as e:
            logger.error(f"Error saving to cache: {e}")

    def get(self, key, expiry_hours=24):
        """Cache-la irunthu data-va edukka (expiry check-odaa)"""
        path = self.get_cache_path(key)
        
        if not os.path.exists(path):
            return None
            
        # File evlo palayasu-nu check pannuvom
        file_time = os.path.getmtime(path)
        if (time.time() - file_time) > (expiry_hours * 3600):
            logger.info(f"Cache expired for key: {key}")
            return None
            
        try:
            with open(path, 'rb') as f:
                logger.info(f"Loading data from cache: {key}")
                return pickle.load(f)
        except Exception as e:
            logger.error(f"Error reading cache: {e}")
            return None

    def clear_all(self):
        """Full cache-aiyum clean panna"""
        for file in os.listdir(self.cache_dir):
            os.remove(os.path.join(self.cache_dir, file))
        logger.info("All cache files cleared.")

# Global Cache Instance
sim_cache = SimulationCache()