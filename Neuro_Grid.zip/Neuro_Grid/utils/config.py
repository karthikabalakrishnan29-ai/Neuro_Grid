import os
from pathlib import Path

# Base Directory Setup
BASE_DIR = Path(__file__).resolve().parent.parent

# Data Paths
DATA_DIR = BASE_DIR / "data"
RAW_DATA_DIR = DATA_DIR / "raw"
PROCESSED_DATA_DIR = DATA_DIR / "processed"

# File Paths (Based on your uploaded files)
HOUSEHOLD_DATA_PATH = RAW_DATA_DIR / "household_data.csv"
MICROGRID_DATA_PATH = RAW_DATA_DIR / "microgrid_dataset_1000_rows.csv"
SMARTGRID_DATA_PATH = RAW_DATA_DIR / "smart_grid_dataset.csv"

# Model Storage
MODEL_SAVE_DIR = BASE_DIR / "models"

# Ensure folders exist
for folder in [RAW_DATA_DIR, PROCESSED_DATA_DIR, MODEL_SAVE_DIR]:
    folder.mkdir(parents=True, exist_ok=True)