import os
from pathlib import Path

# Project Root setup
BASE_DIR = Path(__file__).resolve().parent.parent

# Data Folders
DATA_RAW = os.path.join(BASE_DIR, "data", "raw")
MODELS_DIR = os.path.join(BASE_DIR, "models")

# Dataset File Names
HOUSEHOLD_CSV = os.path.join(DATA_RAW, "household_data.csv")
MICROGRID_CSV = os.path.join(DATA_RAW, "microgrid_dataset_1000_rows.csv")
SMARTGRID_CSV = os.path.join(DATA_RAW, "smart_grid_dataset.csv")

# Constants
SAMPLING_RATE = "15min"
TARGET_VOLTAGE = 230.0