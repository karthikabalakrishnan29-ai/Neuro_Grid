import time
from utils.logger import logger

def time_it(func):
    """Function evlo neram run aaguthu-nu track panna"""
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        logger.info(f"Execution of {func.__name__}: {round(end-start, 4)}s")
        return result
    return wrapper