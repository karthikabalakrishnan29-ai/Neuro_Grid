import pandas as pd
import json
from utils.logger import logger

def save_simulation_results(df, filename="last_run.csv"):
    from utils.config import PROCESSED_DATA_DIR
    path = PROCESSED_DATA_DIR / filename
    df.to_csv(path, index=False)
    logger.info(f"Results saved to {path}")

def load_config_json(config_path):
    with open(config_path, 'r') as f:
        return json.load(f)