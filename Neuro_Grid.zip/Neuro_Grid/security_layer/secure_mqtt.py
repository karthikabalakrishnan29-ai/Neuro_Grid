from iot_layer.mqtt.mqtt_client import MicrogridMQTTClient
from utils.config import MQTT_USER, MQTT_PWD

class SecureMQTTWrapper:
    def __init__(self, client_id):
        self.client = MicrogridMQTTClient(client_id)
        # Broker-kku authentication details set panrom
        self.client.client.username_pw_set(MQTT_USER, MQTT_PWD)
        # Real-world-la inga SSL certificate path kuduppom
        # self.client.client.tls_set(ca_certs="ca.crt")

    def connect_securely(self):
        try:
            self.client.connect()
            return True
        except Exception as e:
            return False