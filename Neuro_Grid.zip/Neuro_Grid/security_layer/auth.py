import hashlib
from utils.logger import logger

class AuthManager:
    def __init__(self):
        # Inga real database illaama demo-kaga hardcoded credentials
        self.users = {
            "admin": hashlib.sha256("admin123".encode()).hexdigest(),
            "operator": hashlib.sha256("op456".encode()).hexdigest()
        }

    def verify_login(self, username, password):
        hashed_pwd = hashlib.sha256(password.encode()).hexdigest()
        if username in self.users and self.users[username] == hashed_pwd:
            logger.info(f"User {username} logged in successfully.")
            return True
        logger.warning(f"Failed login attempt for user: {username}")
        return False