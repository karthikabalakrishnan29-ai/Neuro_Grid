from cryptography.fernet import Fernet
import os

class DataEncryptor:
    def __init__(self):
        # Key generate panni save pannuvom (Demo logic)
        self.key = Fernet.generate_key()
        self.cipher = Fernet(self.key)

    def encrypt_data(self, data_str):
        """String data-va encrypted bytes-ah mathum"""
        return self.cipher.encrypt(data_str.encode())

    def decrypt_data(self, encrypted_data):
        """Encrypted data-va thirumba readable string-ah mathum"""
        return self.cipher.decrypt(encrypted_data).decode()