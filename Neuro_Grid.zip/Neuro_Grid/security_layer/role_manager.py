class RoleManager:
    def __init__(self):
        self.roles = {
            "ADMIN": ["VIEW_DASHBOARD", "CONTROL_RELAY", "CHANGE_SETPOINTS", "SHUTDOWN"],
            "OPERATOR": ["VIEW_DASHBOARD", "CONTROL_RELAY"],
            "VIEWER": ["VIEW_DASHBOARD"]
        }

    def can_perform_action(self, role, action):
        """Action panna permission irukkanu check pannum"""
        permissions = self.roles.get(role.upper(), [])
        return action in permissions