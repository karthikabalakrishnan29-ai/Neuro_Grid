import unittest
import requests
from utils.logger import logger

class TestMicrogridAPI(unittest.TestCase):
    # Base URL unga main_api.py-la enna kudukureengalo athu (default 8000)
    BASE_URL = "http://127.0.0.1:8000"

    def test_01_api_health(self):
        """Check if the API server is reachable"""
        try:
            # 2 seconds mela response illana timeout aydum
            response = requests.get(f"{self.BASE_URL}/health", timeout=2)
            self.assertEqual(response.status_code, 200)
            logger.info("API Health Check: PASSED")
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout):
            # Server run aagala na error kaatama skip pannum
            self.skipTest("API Server is not running. Start main_api.py first.")

    def test_02_forecast_endpoint(self):
        """Check if forecast data is accessible via API"""
        try:
            response = requests.get(f"{self.BASE_URL}/api/v1/forecast/load", timeout=2)
            if response.status_code == 200:
                data = response.json()
                self.assertIn('predictions', data)
        except Exception:
            self.skipTest("API Endpoint not reachable.")

if __name__ == '__main__':
    unittest.main()