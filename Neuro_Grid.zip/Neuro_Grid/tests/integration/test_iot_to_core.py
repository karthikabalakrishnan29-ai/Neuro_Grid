import unittest
from iot_layer.sensor_data_simulator import SensorSimulator
from core_layer.simulation.energy_balance import EnergyBalancer

class TestIoTIntegration(unittest.TestCase):
    def test_iot_simulation_link(self):
        simulator = SensorSimulator()
        balancer = EnergyBalancer()
        
        # Dummy sensor read
        data = simulator.get_current_reading()
        
        # Simulation input check
        result = balancer.calculate_balance(data['solar'], data['wind'], data['load'])
        self.assertIsInstance(result, float)