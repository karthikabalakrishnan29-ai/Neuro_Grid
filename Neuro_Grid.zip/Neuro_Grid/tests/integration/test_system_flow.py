import unittest
from core_layer.preprocessing.pipeline import DataPipeline
from core_layer.forecasting.load.ensemble import LoadForecaster # Future model

class TestSystemIntegration(unittest.TestCase):
    def setUp(self):
        self.pipeline = DataPipeline()
        # Ippo dummy-ah oru setup
        
    def test_end_to_end_data_flow(self):
        # 1. Raw data-va load pannu
        raw_data = self.pipeline.process_microgrid_data()
        self.assertIsNotNone(raw_data)
        
        # 2. Features clean aagi varutha-nu check pannu
        features = self.pipeline.get_combined_features()
        self.assertEqual(len(features.columns), 4) # Solar, Wind, Load, SOC
        
        # 3. Intha data-va Forecasting-ku kudukka mudiyuma-nu check
        # (Inge model prediction check pannalam)
        print("Integration Check: Pipeline to Feature Store - SUCCESS")

if __name__ == '__main__':
    unittest.main()