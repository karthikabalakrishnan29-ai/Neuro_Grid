import unittest
from core_layer.assets.solar_panel import SolarPanel
from core_layer.assets.battery_model import BatterySystem

class TestMicrogridAssets(unittest.TestCase):
    def setUp(self):
        self.solar = SolarPanel(efficiency=0.2, area=10)
        self.battery = BatterySystem(capacity_kwh=100, initial_soc=50)

    def test_solar_output(self):
        # High irradiance-la positive power varutha-nu check panna
        power = self.solar.calculate_power(irradiance=1000, temperature=25)
        self.assertGreater(power, 0)
        # Irradiance 0-na power-um 0-ah irukanum
        self.assertEqual(self.solar.calculate_power(0, 25), 0)

    def test_battery_charging(self):
        # Battery charge aagura logic test
        initial_soc = self.battery.soc
        # Positive power input (charging)
        new_soc = self.battery.update_soc(net_power=20, duration_hrs=1)
        self.assertGreater(new_soc, initial_soc)

    def test_battery_limits(self):
        # Battery 100% mela poga koodathu (Safety limits check)
        self.battery.update_soc(net_power=1000, duration_hrs=10)
        self.assertLessEqual(self.battery.soc, 95)

if __name__ == '__main__':
    unittest.main()