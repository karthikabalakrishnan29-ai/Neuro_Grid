import unittest
import pandas as pd
from core_layer.preprocessing.pipeline import DataPipeline

class TestDataPipeline(unittest.TestCase):
    def setUp(self):
        self.pipeline = DataPipeline()

    def test_microgrid_load(self):
        df = self.pipeline.process_microgrid_data()
        self.assertIsInstance(df, pd.DataFrame)
        # 1000 rows dataset-la columns irukka-nu check panna
        self.assertIn('Solar_Power_kW', df.columns)
        self.assertIn('Fault_Label', df.columns)

    def test_household_separator(self):
        df = self.pipeline.process_household_data()
        # Semicolon handle aagi columns split aagirukka-nu check
        self.assertGreater(len(df.columns), 1)
        self.assertIn('Global_active_power', df.columns)

if __name__ == '__main__':
    unittest.main()