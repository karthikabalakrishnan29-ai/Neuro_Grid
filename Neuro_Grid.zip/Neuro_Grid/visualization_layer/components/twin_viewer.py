import streamlit as st
import pandas as pd
import plotly.graph_objects as go

class DigitalTwinViewer:
    @staticmethod
    def render_twin_comparison(physical_data, virtual_data):
        """
        Physical sensor data vs Virtual simulation data comparison.
        """
        st.subheader("🔗 Physical vs. Virtual Synchronization")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.info("🌐 Physical Asset (IoT)")
            st.metric("Grid Voltage", f"{physical_data['v']} V", delta="-1.2V")
            st.metric("Measured Current", f"{physical_data['i']} A")

        with col2:
            st.success("🤖 Virtual Twin (Simulated)")
            st.metric("Simulated Voltage", f"{virtual_data['v']} V", delta="Stable")
            st.metric("Predicted Current", f"{virtual_data['i']} A")

    @staticmethod
    def render_sync_error_chart(history_df):
        """
        Deviation (Error) between Twin and Reality over time.
        """
        st.subheader("📉 Twin Deviation Analysis (Accuracy)")
        
        # Calculate Error: Physical - Virtual
        history_df['Error'] = history_df['Physical_V'] - history_df['Virtual_V']
        
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=history_df['Time'], y=history_df['Error'],
                                 mode='lines+markers',
                                 name='Sync Error',
                                 line=dict(color='firebrick', width=2)))
        
        fig.update_layout(title="Mirroring Error (Voltage Gap)",
                          xaxis_title="Timestamp",
                          yaxis_title="Error (Volts)")
        
        st.plotly_chart(fig, use_container_width=True)

    @staticmethod
    def render_3d_perspective():
        """
        Placeholder for 3D/Map visualization (using pydeck or svg).
        """
        st.subheader("🗺️ Spatial Digital Twin View")
        st.warning("3D Model: Loading Photogrammetry Data...")
        # Inga unga 'assets/microgrid_schematic.svg'-a oru 3D perspective-la load pannalam.