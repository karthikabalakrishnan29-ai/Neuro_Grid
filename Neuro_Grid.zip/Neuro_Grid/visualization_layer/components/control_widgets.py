import streamlit as st
from control_layer.actuator_interface import ActuatorInterface
from utils.logger import logger

class ControlWidgets:
    def __init__(self):
        self.actuator = ActuatorInterface()

    def render_relay_controls(self):
        """Main Circuit Breakers and Relay Switches"""
        st.subheader("🔌 Hardware Relay Control")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Solar Grid Tie**")
            if st.button("ON", key="solar_on", use_container_width=True):
                self.actuator.send_signal("Solar_Relay", "CLOSE")
                st.toast("Solar Relay Closed!", icon="✅")
            
            if st.button("OFF", key="solar_off", use_container_width=True):
                self.actuator.send_signal("Solar_Relay", "OPEN")
                st.toast("Solar Relay Opened!", icon="🛑")

        with col2:
            st.write("**Main Utility Grid**")
            grid_status = st.toggle("Grid Connection", value=True)
            if grid_status:
                self.actuator.send_signal("Main_Grid", "CONNECT")
            else:
                self.actuator.send_signal("Main_Grid", "DISCONNECT")

    def render_setpoint_sliders(self):
        """Voltage and Frequency Setpoint adjustments"""
        st.subheader("⚙️ Operational Setpoints")
        
        v_setpoint = st.slider("Target Voltage (V)", 210.0, 250.0, 230.0, step=0.5)
        f_setpoint = st.slider("Grid Frequency (Hz)", 48.0, 52.0, 50.0, step=0.1)
        
        if st.button("Apply Setpoints"):
            # Inga logic-a 'control_layer/setpoint_manager.py'-ku forward pannuvom
            logger.info(f"New Setpoints Applied: {v_setpoint}V, {f_setpoint}Hz")
            st.success(f"Setpoints updated to {v_setpoint}V")

    def render_mode_selector(self):
        """Microgrid Mode Selection (Island vs Grid-Tied)"""
        st.subheader("🛡️ System Mode")
        
        mode = st.selectbox("Select Operation Mode", 
                            ["Grid-Tied (Standard)", "Islanded (Emergency)", "Economic (Market-Driven)"])
        
        if mode == "Islanded (Emergency)":
            st.warning("⚠️ System is now running on internal storage only!")
        
        return mode