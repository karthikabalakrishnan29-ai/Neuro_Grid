import streamlit as st

def render_sidebar_alerts():
    with st.sidebar.expander("🔔 System Notifications", expanded=True):
        st.caption("12:30 PM: Solar Efficiency 95%")
        st.warning("12:44 PM: High Load Detected in Sector B")
        st.error("12:45 PM: Inverter 1 Communication Timeout")