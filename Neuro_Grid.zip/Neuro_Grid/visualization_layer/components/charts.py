import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd

class MicrogridCharts:
    @staticmethod
    def render_power_balance(df):
        """
        Solar Generation vs Load Demand Comparison Chart.
        df structure: ['Timestamp', 'Solar_kW', 'Load_kW']
        """
        st.subheader("📊 Generation vs. Consumption")
        fig = px.area(df, x='Timestamp', y=['Solar_kW', 'Load_kW'],
                      title="Real-time Power Balance",
                      color_discrete_map={"Solar_kW": "#FFD700", "Load_kW": "#FF4B4B"},
                      labels={"value": "Power (kW)", "variable": "Source"})
        
        fig.update_layout(hovermode="x unified", legend_orientation="h")
        st.plotly_chart(fig, use_container_width=True)

    @staticmethod
    def render_battery_soc_gauge(current_soc):
        """
        Battery State of Charge (SoC) Gauge Chart.
        """
        fig = go.Figure(go.Indicator(
            mode = "gauge+number",
            value = current_soc,
            domain = {'x': [0, 1], 'y': [0, 1]},
            title = {'text': "Battery SoC (%)", 'font': {'size': 24}},
            gauge = {
                'axis': {'range': [0, 100], 'tickwidth': 1},
                'bar': {'color': "#00CC96" if current_soc > 20 else "#EF553B"},
                'steps': [
                    {'range': [0, 20], 'color': "lightpink"},
                    {'range': [20, 80], 'color': "lightgray"},
                    {'range': [80, 100], 'color': "lightgreen"}],
                'threshold': {
                    'line': {'color': "red", 'width': 4},
                    'thickness': 0.75,
                    'value': 15}
            }
        ))
        st.plotly_chart(fig, use_container_width=True)

    @staticmethod
    def render_forecast_overlay(historical_df, forecast_df):
        """
        Past data kooda future prediction-a overlay panni kaatta.
        """
        st.subheader("🔮 Load Forecast Analysis")
        fig = go.Figure()

        # Historical Data
        fig.add_trace(go.Scatter(x=historical_df['Time'], y=historical_df['Load'], 
                                 name='Actual Load', line=dict(color='blue')))

        # Forecasted Data (Dashed Line)
        fig.add_trace(go.Scatter(x=forecast_df['Time'], y=forecast_df['Pred'], 
                                 name='AI Forecast', line=dict(color='orange', dash='dash')))

        fig.update_layout(title="Load Trend: Actual vs Predicted", 
                          xaxis_title="Time", yaxis_title="kW")
        st.plotly_chart(fig, use_container_width=True)