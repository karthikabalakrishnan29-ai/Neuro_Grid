import streamlit as st

def render_kpis(data):
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Solar Gen", f"{data['solar_kw']} kW", "+2.5%")
    col2.metric("Wind Gen", f"{data['wind_kw']} kW", "-1.2%")
    col3.metric("Load Demand", f"{data['load_kw']} kW", "Stable")
    
    # Battery SOC with color logic
    soc = data['battery_soc']
    col4.metric("Battery SOC", f"{soc}%", delta_color="normal")