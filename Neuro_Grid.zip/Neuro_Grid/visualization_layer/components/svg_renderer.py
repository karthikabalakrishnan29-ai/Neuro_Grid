import streamlit as st
import os

def render_microgrid_svg(solar_active=False):
    svg_path = "visualization_layer/assets/microgrid_schematic.svg"
    
    if not os.path.exists(svg_path):
        st.error("SVG Path Thappu mapla!")
        return

    with open(svg_path, "r") as f:
        svg_code = f.read()

    # --- ULTIMATE HTML OVERLAY (No SVG editing needed) ---
    st.markdown(f"""
        <div style="position: relative; width: fit-content; margin: auto;">
            {svg_code}
            
            <div style="
                position: absolute;
                top: 250px; 
                left: 200px;
                background: #1e1e1e;
                color: #00d1ff;
                border: 2px solid #00d1ff;
                padding: 2px 8px;
                border-radius: 5px;
                font-family: sans-serif;
                font-size: 12px;
                font-weight: bold;
                z-index: 999;
                box-shadow: 0px 0px 10px #00d1ff;
            ">
                AC ⇁ DC
            </div>
        </div>
    """, unsafe_allow_html=True)