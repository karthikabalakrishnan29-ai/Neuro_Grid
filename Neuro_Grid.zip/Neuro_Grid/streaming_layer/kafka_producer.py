from kafka import KafkaProducer
import json
from utils.logger import logger

class MicrogridProducer:
    def __init__(self, broker='localhost:9092'):
        self.producer = KafkaProducer(
            bootstrap_servers=[broker],
            value_serializer=lambda v: json.dumps(v).encode('utf-8')
        )

    def send_telemetry(self, data):
        """IoT data-va 'microgrid-telemetry' topic-ku anupum"""
        try:
            self.producer.send('microgrid-telemetry', data)
            self.producer.flush()
        except Exception as e:
            logger.error(f"Kafka Producer Error: {e}")