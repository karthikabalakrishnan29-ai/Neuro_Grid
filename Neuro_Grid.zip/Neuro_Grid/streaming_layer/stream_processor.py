class StreamProcessor:
    def __init__(self):
        self.buffer = []

    def process_window(self, new_data):
        """Sliding Window analysis for stability"""
        self.buffer.append(new_data['voltage'])
        if len(self.buffer) > 10:
            self.buffer.pop(0)
            
        avg_v = sum(self.buffer) / len(self.buffer)
        return {"avg_voltage": round(avg_v, 2)}