from kafka import KafkaConsumer
import json

class MicrogridConsumer:
    def __init__(self, topic='microgrid-telemetry', broker='localhost:9092'):
        self.consumer = KafkaConsumer(
            topic,
            bootstrap_servers=[broker],
            auto_offset_reset='latest',
            value_deserializer=lambda x: json.loads(x.decode('utf-8'))
        )

    def consume_data(self):
        print("📥 Listening to Kafka Stream...")
        for message in self.consumer:
            data = message.value
            # Inga thaan namma 'Intelligence Layer'-a trigger pannuvom
            print(f"Received Stream Data: {data}")