# 🔧 Fix import path
import sys
import os

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(BASE_DIR)

# 📦 Imports
from iot_layer.sensor_data_simulator import SensorSimulator
from iot_layer.edge_processing.edge_filter import filter_data
from iot_layer.edge_processing.edge_aggregation import aggregate_data
from iot_layer.mqtt.mqtt_client import MQTTClient
from iot_layer.mqtt.topic_manager import get_topic


def run_iot_pipeline():
    print("🚀 Starting IoT Simulation...\n")

    # ✅ AUTO FIND DATASET (no path headache)
    dataset_path = os.path.join(BASE_DIR, "data", "raw")

    file_found = None
    for root, dirs, files in os.walk(dataset_path):
        for file in files:
            if file.endswith(".csv"):
                file_found = os.path.join(root, file)
                break

    if not file_found:
        print("❌ No CSV dataset found inside data/raw/")
        return

    print(f"✅ Using dataset: {file_found}")

    # Initialize
    sim = SensorSimulator(file_found)
    mqtt = MQTTClient()

    # Run only limited times (avoid infinite loop)
    for i, data in enumerate(sim.stream(delay=1)):
        
        if i >= 10:   # limit
            print("\n✅ Simulation completed")
            break

        # Step 1: Filter
        filtered = filter_data(data)
        if not filtered:
            continue

        # Step 2: Aggregate
        aggregated = aggregate_data(filtered)

        print("\n📡 Data Packet:")
        print(aggregated)

        # Step 3: Publish
        for key, value in aggregated.items():
            topic = get_topic(key)
            mqtt.publish(topic, value)


if __name__ == "__main__":
    run_iot_pipeline()