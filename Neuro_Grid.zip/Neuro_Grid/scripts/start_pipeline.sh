#!/bin/bash

echo "🚀 Starting Intelligent Microgrid Digital Twin Pipeline..."

# 1. Start MQTT Broker (If not running)
# mosquitto -d

# 2. Start FastAPI Backend in background
echo "Starting API Layer..."
uvicorn api_layer.main_api:app --host 0.0.0.0 --port 8000 &

# 3. Start Simulation Engine in background
echo "Starting Simulation Engine..."
python scripts/run_simulation.py &

# 4. Start Streamlit Dashboard
echo "Launching Visualization Dashboard..."
streamlit run visualization_layer/dashboard.py

echo "✅ All systems are live!"