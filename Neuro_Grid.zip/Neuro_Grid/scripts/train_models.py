import sys
import os

# 1. Path setup (Import errors varaama irukka)
sys.path.append(os.path.abspath(os.path.dirname(__file__) + '/..'))

import pandas as pd
import joblib 
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report

print("🚀 Microgrid Intelligence: Training Started...\n")

# 2. Load Data
data_path = "data/processed/final_training_data.csv"
if not os.path.exists(data_path):
    print(f"❌ Error: {data_path} kaanom! Data processing munnadi pannunga.")
    sys.exit()

df = pd.read_csv(data_path)

# 3. Target Detection
target = None
for col in ["Fault_Label", "fault", "target", "anomaly"]:
    if col in df.columns:
        target = col
        break

if not target:
    print("❌ Error: Target column (Fault Label) kandupudikka mudiyala!")
    sys.exit()

print(f"📊 Target Detected: '{target}'")

# 4. Features Selection (Numeric data-va mattum filter panrom)
# Target-a drop pannitu, timestamps/strings-a select_dtypes moolama remove panrom
X = df.drop(columns=[target])
X = X.select_dtypes(include=['number', 'float', 'int']) 
y = df[target]

feature_names = X.columns.tolist()
print(f"💡 Training with {len(feature_names)} features: {feature_names}")

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 5. Model Training
print("🧠 Training Random Forest Model...")
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# 6. Evaluation
acc = model.score(X_test, y_test)
print(f"\n✅ Model Accuracy: {acc:.2f}")

y_pred = model.predict(X_test)
print("\n📝 Detailed Report:")
print(classification_report(y_test, y_pred))

# 7. Save Model & Features (Final Output)
os.makedirs("models/anomaly", exist_ok=True)
model_file = "models/anomaly/anomaly_detector_v1.pkl"
feature_file = "models/anomaly/feature_names.pkl"

joblib.dump(model, model_file)
joblib.dump(feature_names, feature_file)

print(f"\n🎉 Success: Model saved at {model_file}")